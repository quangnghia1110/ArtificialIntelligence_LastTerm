from typing import Type
import CSP_Problem as csp

class Problem_solver:
    def __init__(self): pass
    def train(self, problem: Type[csp.CSP_Problem]): pass
    def solve(self): pass